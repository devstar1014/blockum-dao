const nextConfig = {
  reactStrictMode: false,
};
module.exports = nextConfig;
