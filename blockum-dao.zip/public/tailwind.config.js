tailwind.config = {
  prefix: 't-',
  theme: {
    extend: {
      colors: {
        clifford: "#da373d",
      },
    },
  },
}